/* PPTX 生成器：纯 JS 拼 zip，不依赖任何库。
   图片一页一张，等比铺满 16:9 幻灯片。 */
(function (root) {
  'use strict';

  const SLIDE_CX = 12192000; // 13.333 英寸
  const SLIDE_CY = 6858000; // 7.5 英寸

  /* ---------------- CRC32 ---------------- */
  const CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[i] = c >>> 0;
    }
    return t;
  })();

  function crc32(buf) {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }

  /* ---------------- 不压缩的 zip ---------------- */
  function zipStore(files) {
    const enc = new TextEncoder();
    const chunks = [];
    const central = [];
    let offset = 0;

    // 固定成一个时间戳，避免每次生成的文件 hash 都变
    const dosTime = 0;
    const dosDate = ((2024 - 1980) << 9) | (1 << 5) | 1;

    for (const f of files) {
      const nameBytes = enc.encode(f.name);
      const data = f.data;
      const crc = crc32(data);

      const local = new Uint8Array(30 + nameBytes.length);
      const lv = new DataView(local.buffer);
      lv.setUint32(0, 0x04034b50, true);
      lv.setUint16(4, 20, true);
      lv.setUint16(6, 0x0800, true); // UTF-8 文件名
      lv.setUint16(8, 0, true); // store
      lv.setUint16(10, dosTime, true);
      lv.setUint16(12, dosDate, true);
      lv.setUint32(14, crc, true);
      lv.setUint32(18, data.length, true);
      lv.setUint32(22, data.length, true);
      lv.setUint16(26, nameBytes.length, true);
      lv.setUint16(28, 0, true);
      local.set(nameBytes, 30);

      chunks.push(local, data);

      const cd = new Uint8Array(46 + nameBytes.length);
      const cv = new DataView(cd.buffer);
      cv.setUint32(0, 0x02014b50, true);
      cv.setUint16(4, 20, true);
      cv.setUint16(6, 20, true);
      cv.setUint16(8, 0x0800, true);
      cv.setUint16(10, 0, true);
      cv.setUint16(12, dosTime, true);
      cv.setUint16(14, dosDate, true);
      cv.setUint32(16, crc, true);
      cv.setUint32(20, data.length, true);
      cv.setUint32(24, data.length, true);
      cv.setUint16(28, nameBytes.length, true);
      cv.setUint16(30, 0, true);
      cv.setUint16(32, 0, true);
      cv.setUint16(34, 0, true);
      cv.setUint16(36, 0, true);
      cv.setUint32(38, 0, true);
      cv.setUint32(42, offset, true);
      cd.set(nameBytes, 46);
      central.push(cd);

      offset += local.length + data.length;
    }

    let cdSize = 0;
    for (const c of central) cdSize += c.length;

    const eocd = new Uint8Array(22);
    const ev = new DataView(eocd.buffer);
    ev.setUint32(0, 0x06054b50, true);
    ev.setUint16(8, central.length, true);
    ev.setUint16(10, central.length, true);
    ev.setUint32(12, cdSize, true);
    ev.setUint32(16, offset, true);

    const total = offset + cdSize + 22;
    const out = new Uint8Array(total);
    let p = 0;
    for (const c of chunks) {
      out.set(c, p);
      p += c.length;
    }
    for (const c of central) {
      out.set(c, p);
      p += c.length;
    }
    out.set(eocd, p);
    return out;
  }

  /* ---------------- 读图片尺寸 ---------------- */
  function imageSize(data) {
    try {
      // PNG
      if (data.length > 24 && data[0] === 0x89 && data[1] === 0x50) {
        const v = new DataView(data.buffer, data.byteOffset, data.byteLength);
        return { w: v.getUint32(16), h: v.getUint32(20) };
      }
      // JPEG
      if (data[0] === 0xff && data[1] === 0xd8) {
        let i = 2;
        while (i + 9 < data.length) {
          if (data[i] !== 0xff) {
            i++;
            continue;
          }
          const m = data[i + 1];
          if (m === 0xd8 || m === 0x01 || (m >= 0xd0 && m <= 0xd7)) {
            i += 2;
            continue;
          }
          const len = (data[i + 2] << 8) | data[i + 3];
          if (m >= 0xc0 && m <= 0xcf && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) {
            const h = (data[i + 5] << 8) | data[i + 6];
            const w = (data[i + 7] << 8) | data[i + 8];
            return { w, h };
          }
          i += 2 + len;
        }
      }
    } catch {
      /* ignore */
    }
    return { w: 1280, h: 720 };
  }

  /* ---------------- XML 部件 ---------------- */
  const XML_HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';

  const NS =
    'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" ' +
    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ' +
    'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"';

  const REL_NS = 'xmlns="http://schemas.openxmlformats.org/package/2006/relationships"';
  const REL_BASE = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/';

  function esc(s) {
    return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  }

  function contentTypes(n, exts) {
    let s = XML_HEAD + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">';
    s += '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>';
    s += '<Default Extension="xml" ContentType="application/xml"/>';
    for (const e of exts) s += `<Default Extension="${e}" ContentType="image/${e === 'png' ? 'png' : 'jpeg'}"/>`;
    s += '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>';
    s += '<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>';
    s += '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>';
    s += '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>';
    s += '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>';
    s += '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>';
    for (let i = 1; i <= n; i++) {
      s += `<Override PartName="/ppt/slides/slide${i}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`;
    }
    return s + '</Types>';
  }

  function rootRels() {
    return (
      XML_HEAD +
      `<Relationships ${REL_NS}>` +
      `<Relationship Id="rId1" Type="${REL_BASE}officeDocument" Target="ppt/presentation.xml"/>` +
      '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>' +
      `<Relationship Id="rId3" Type="${REL_BASE}extended-properties" Target="docProps/app.xml"/>` +
      '</Relationships>'
    );
  }

  function presentationXml(n) {
    let ids = '';
    for (let i = 1; i <= n; i++) ids += `<p:sldId id="${255 + i}" r:id="rId${i + 1}"/>`;
    return (
      XML_HEAD +
      `<p:presentation ${NS}>` +
      '<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>' +
      `<p:sldIdLst>${ids}</p:sldIdLst>` +
      `<p:sldSz cx="${SLIDE_CX}" cy="${SLIDE_CY}"/>` +
      '<p:notesSz cx="6858000" cy="9144000"/>' +
      '</p:presentation>'
    );
  }

  function presentationRels(n) {
    let s = XML_HEAD + `<Relationships ${REL_NS}>`;
    s += `<Relationship Id="rId1" Type="${REL_BASE}slideMaster" Target="slideMasters/slideMaster1.xml"/>`;
    for (let i = 1; i <= n; i++) {
      s += `<Relationship Id="rId${i + 1}" Type="${REL_BASE}slide" Target="slides/slide${i}.xml"/>`;
    }
    s += `<Relationship Id="rId${n + 2}" Type="${REL_BASE}theme" Target="theme/theme1.xml"/>`;
    return s + '</Relationships>';
  }

  function slideXml(i, cx, cy, offX, offY, descr) {
    return (
      XML_HEAD +
      `<p:sld ${NS}>` +
      '<p:cSld><p:spTree>' +
      '<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>' +
      '<p:grpSpPr/>' +
      '<p:pic><p:nvPicPr>' +
      `<p:cNvPr id="2" name="图片 ${i}" descr="${esc(descr)}"/>` +
      '<p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/>' +
      '</p:nvPicPr>' +
      '<p:blipFill><a:blip r:embed="rId2"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>' +
      `<p:spPr><a:xfrm><a:off x="${offX}" y="${offY}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm>` +
      '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>' +
      '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>'
    );
  }

  function slideRels(i, ext) {
    return (
      XML_HEAD +
      `<Relationships ${REL_NS}>` +
      `<Relationship Id="rId1" Type="${REL_BASE}slideLayout" Target="../slideLayouts/slideLayout1.xml"/>` +
      `<Relationship Id="rId2" Type="${REL_BASE}image" Target="../media/image${i}.${ext}"/>` +
      '</Relationships>'
    );
  }

  /* ---------------- 组装 ---------------- */

  function escapeXml(s) {
    return String(s)
      .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function appXml(n) {
    return (
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n' +
      '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" ' +
      'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">' +
      '<Application>Microsoft Office PowerPoint</Application>' +
      '<Slides>' + n + '</Slides>' +
      '</Properties>'
    );
  }


  function coreXml(title) {
    return (
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n' +
      '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" ' +
      'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" ' +
      'xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' +
      `<dc:title>${escapeXml(title || '')}</dc:title>` +
      '<dc:creator>问渠学堂 PPT 抓取</dc:creator>' +
      '<cp:lastModifiedBy>问渠学堂 PPT 抓取</cp:lastModifiedBy>' +
      '</cp:coreProperties>'
    );
  }

  /**
   * @param {Array<{data: Uint8Array, ext?: string, descr?: string}>} images
   * @param {{title?: string}} opts
   * @returns {Uint8Array}
   */
  function buildPptx(images, opts) {
    const o = opts || {};
    const enc = new TextEncoder();
    const files = [];
    const n = images.length;
    if (!n) throw new Error('没有图片');

    const exts = new Set(['jpg']);
    images.forEach((im, i) => {
      const ext = (im.ext || 'jpg').toLowerCase() === 'png' ? 'png' : 'jpg';
      exts.add(ext);
      const { w, h } = imageSize(im.data);
      const scale = Math.min(SLIDE_CX / w, SLIDE_CY / h);
      const cw = Math.round(w * scale);
      const ch = Math.round(h * scale);
      const ox = Math.round((SLIDE_CX - cw) / 2);
      const oy = Math.round((SLIDE_CY - ch) / 2);
      files.push({
        name: `ppt/slides/slide${i + 1}.xml`,
        data: enc.encode(slideXml(i + 1, cw, ch, ox, oy, im.descr || `第 ${i + 1} 页`)),
      });
      files.push({ name: `ppt/slides/_rels/slide${i + 1}.xml.rels`, data: enc.encode(slideRels(i + 1, ext)) });
      files.push({ name: `ppt/media/image${i + 1}.${ext}`, data: im.data });
    });

    files.push({ name: '[Content_Types].xml', data: enc.encode(contentTypes(n, [...exts])) });
    files.push({ name: '_rels/.rels', data: enc.encode(rootRels()) });
    files.push({ name: 'ppt/presentation.xml', data: enc.encode(presentationXml(n)) });
    files.push({ name: 'ppt/_rels/presentation.xml.rels', data: enc.encode(presentationRels(n)) });

    const fixed = root.PPTX_FIXED || {};
    for (const name of Object.keys(fixed)) {
      files.push({ name, data: enc.encode(fixed[name]) });
    }

    files.push({ name: 'docProps/core.xml', data: enc.encode(coreXml(o.title || '')) });
    files.push({ name: 'docProps/app.xml', data: enc.encode(appXml(n)) });

    return zipStore(files);
  }

  root.PPTX = { buildPptx, zipStore, crc32, imageSize };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.PPTX;
})(typeof globalThis !== 'undefined' ? globalThis : this);
