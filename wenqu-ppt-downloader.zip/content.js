/* 问渠学堂 PPT 抓取 — 页面扫描脚本
 * 只在 popup 发消息时干活，平时只挂一个监听器。
 */
(() => {
  if (window.__WQ_PPT_SCANNER__) return;
  window.__WQ_PPT_SCANNER__ = true;

  const PPT_RE = /\.(pptx?|ppsx?|potx?)(?=$|[?#&])/i;
  const DOC_RE = /\.(pdf|docx?|xlsx?|zip|rar|7z)(?=$|[?#&])/i;
  const ANY_RE = /\.(pptx?|ppsx?|potx?|pdf|docx?|xlsx?|zip|rar|7z)(?=$|[?#&])/i;
  const SUSPECT_RE = /(ppt|课件|讲义|幻灯片|演示文稿|幻灯|lecture\s*slides)/i;
  const EXT_RE = /\.([a-z0-9]{2,5})$/i;

  /* 录播回放里的课件截图：/ai3/ppt/20260915/<uuid>/5690720.jpg
   * 这类课的“PPT”其实是按页截的图，没有 pptx 原件，只能按顺序存图再合成。*/
  const SLIDE_RE = /\/ai3\/ppt\/(\d{8})\/([0-9a-f][0-9a-f-]{7,})\/([^/?#]+\.(?:jpe?g|png))(?:[?#]|$)/i;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /** URL -> 绝对地址；失败返回空串 */
  function norm(u) {
    if (!u) return '';
    const s = String(u).trim();
    if (!s || s.length > 4000) return '';
    if (/^(javascript|mailto|tel|about):/i.test(s)) return '';
    try {
      const n = new URL(s, document.baseURI);
      if (!/^https?:$/.test(n.protocol)) return '';
      n.hash = '';
      return n.href;
    } catch {
      return '';
    }
  }

  /** 从 URL 里取扩展名（优先路径，其次查询参数） */
  function extOf(url) {
    try {
      const u = new URL(url);
      const p = decodeURIComponent(u.pathname);
      const m = p.match(EXT_RE);
      if (m) return m[1].toLowerCase();
      for (const v of u.searchParams.values()) {
        const mm = String(v).match(ANY_RE);
        if (mm) return mm[1].toLowerCase();
      }
    } catch {
      /* ignore */
    }
    const m2 = url.match(ANY_RE);
    return m2 ? m2[1].toLowerCase() : '';
  }

  function baseName(url) {
    try {
      const u = new URL(url);
      let last = decodeURIComponent(u.pathname.split('/').filter(Boolean).pop() || '');
      if (last && ANY_RE.test(last)) return last;
      for (const key of ['fileName', 'filename', 'name', 'title', 'realName', 'attname', 'file']) {
        const v = u.searchParams.get(key);
        if (v && ANY_RE.test(v)) return decodeURIComponent(v.split('/').pop() || v);
      }
      return last;
    } catch {
      return '';
    }
  }

  function sanitizeName(name) {
    let s = String(name || '')
      .replace(/[\u0000-\u001f<>:"/\\|?*]/g, '_')
      .replace(/\s+/g, ' ')
      .trim();
    s = s.replace(/^[. ]+/, '').replace(/[. ]+$/, '');
    return s;
  }

  /** 元素上的可读名字：title/aria-label/download > 文本 */
  function labelOf(el) {
    if (!el || !el.getAttribute) return '';
    let t =
      el.getAttribute('title') ||
      el.getAttribute('aria-label') ||
      el.getAttribute('download') ||
      el.getAttribute('data-name') ||
      '';
    if (!t) t = el.textContent || '';
    t = t.replace(/\s+/g, ' ').trim();
    return t.length > 100 ? t.slice(0, 100) : t;
  }

  /** 一段字符串里所有像 URL 的片段 */
  function urlsInValue(v) {
    const out = [];
    const abs = v.match(/(?:https?:)?\/\/[^\s"'<>\\)\]]+/gi) || [];
    const rel = v.match(/(?:^|[\s"'(=,])\/(?!\/)[^\s"'<>\\)\]]+/g) || [];
    for (const s of abs) out.push(s);
    for (let s of rel) out.push(s.replace(/^[\s"'(=,]+/, ''));
    return out.map((s) => s.replace(/[.,;:]+$/, ''));
  }

  const store = new Map(); // url -> { url, name, ext, source }

  function add(url, el, source, opts = {}) {
    const u = norm(url);
    if (!u) return;
    const ext = extOf(u);
    if (!ext) return;
    if (opts.allowDocs ? !ANY_RE.test(u) : !PPT_RE.test(u)) return;

    let name = sanitizeName(labelOf(el) || '');
    if (!name || name.length < 2 || /^(下载|查看|预览|点击|打开|更多)$/.test(name)) name = '';
    if (name && !name.toLowerCase().endsWith('.' + ext) && !EXT_RE.test(name)) name += '.' + ext;

    const prev = store.get(u);
    if (prev) {
      if (!prev.name && name) prev.name = name;
      if (prev.source !== 'network' && source === 'network') prev.source = source;
      return;
    }
    store.set(u, {
      url: u,
      name: name || sanitizeName(baseName(u)) || 'file.' + ext,
      ext,
      source,
    });
  }

  /* ---------- 1. 全属性扫描 ---------- */
  function walkAttributes(root, allowDocs) {
    const all = root.querySelectorAll('*');
    const limit = Math.min(all.length, 15000);
    for (let i = 0; i < limit; i++) {
      const el = all[i];
      if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') continue;
      const attrs = el.attributes;
      for (let j = 0; j < attrs.length; j++) {
        const v = attrs[j].value;
        if (!v || v.length < 6 || v.length > 4000) continue;
        if (!ANY_RE.test(v)) continue;
        for (const u of urlsInValue(v)) add(u, el, 'attr', { allowDocs });
      }
    }
  }

  /* ---------- 2. 链接文字里带“课件/PPT”的可疑链接 ---------- */
  function collectSuspects(doc, limit = 20) {
    const out = [];
    const seen = new Set();
    const anchors = doc.querySelectorAll('a[href], [data-href], [role="button"]');
    for (const a of anchors) {
      if (out.length >= limit) break;
      const href = a.getAttribute('href') || a.getAttribute('data-href') || '';
      if (!href || /^(javascript|mailto|tel|#)/i.test(href)) continue;
      const u = norm(href);
      if (!u) continue;
      // 已经是直链就不算可疑
      if (ANY_RE.test(u) && EXT_RE.test(decodeURIComponent(new URL(u).pathname))) continue;
      const text = (a.textContent || '') + ' ' + (a.getAttribute('title') || '') + ' ' + a.className;
      if (!SUSPECT_RE.test(text)) continue;
      if (seen.has(u)) continue;
      seen.add(u);
      out.push({ url: u, label: labelOf(a) });
    }
    return out;
  }

  /** 打开可疑链接，看响应头/内容里有没有真文件 */
  async function probeLink(url, allowDocs) {
    let resp = null;
    try {
      resp = await fetch(url, {
        credentials: 'include',
        redirect: 'follow',
        signal: AbortSignal.timeout(9000),
      });
    } catch {
      return [];
    }
    if (!resp.ok) return [];
    const ct = (resp.headers.get('content-type') || '').toLowerCase();
    const cd = resp.headers.get('content-disposition') || '';
    const finalUrl = resp.url || url;

    if (
      /officedocument|ms-powerpoint|pdf|octet-stream|application\/zip/.test(ct) ||
      /attachment/i.test(cd)
    ) {
      return [{ url: finalUrl, ct }];
    }
    if (!ct.includes('text/html')) return [];

    let html = '';
    try {
      html = await resp.text();
    } catch {
      return [];
    }
    if (html.length > 4 * 1024 * 1024) html = html.slice(0, 4 * 1024 * 1024);
    const found = new Set();
    const matches = html.match(/(?:https?:)?\/\/[^\s"'<>\\)]+?\.(?:pptx?|ppsx?|potx?|pdf|docx?)(?:\?[^\s"'<>\\)]*)?/gi) || [];
    const rels = html.match(/["'](\/[^"']{4,300}?\.(?:pptx?|ppsx?|potx?|pdf|docx?))(?:\?[^"']*)?["']/gi) || [];
    const list = matches.concat(rels.map((s) => s.replace(/^["']|["']$/g, '')));
    for (const u of list) {
      const n = norm(u);
      if (!n) continue;
      if (allowDocs ? ANY_RE.test(n) : PPT_RE.test(n)) found.add(n);
    }
    return [...found].map((u) => ({ url: u }));
  }

  /* ---------- 3. 网络请求过的资源（performance） ---------- */
  function collectNetwork(win, allowDocs) {
    try {
      const entries = win.performance.getEntriesByType('resource') || [];
      for (const e of entries) {
        const n = e.name;
        if (!n || !ANY_RE.test(n)) continue;
        if (allowDocs ? !ANY_RE.test(n) : !PPT_RE.test(n)) continue;
        add(n, null, 'network', { allowDocs });
      }
    } catch {
      /* 跨域 iframe 拿不到 performance，忽略 */
    }
  }

  /* ---------- 4. 录播课件截图（问渠学堂回放） ---------- */
  const slides = new Map(); // path -> { path, url, ts }

  function addSlide(raw) {
    const m = String(raw).match(SLIDE_RE);
    if (!m) return;
    const [, date, uuid, fname] = m;
    const path = `/ai3/ppt/${date}/${uuid}/${fname}`;
    if (slides.has(path)) return;
    let host = 'video.wqxt.cdut.edu.cn';
    try {
      const h = new URL(raw, document.baseURI).host;
      if (h) host = h;
    } catch {
      /* ignore */
    }
    const num = String(fname).match(/(\d+)/);
    slides.set(path, { path, url: `https://${host}${path}`, ts: num ? Number(num[1]) : 0, date });
  }

  function walkSlides(doc) {
    const all = doc.querySelectorAll('*');
    const limit = Math.min(all.length, 15000);
    for (let i = 0; i < limit; i++) {
      const el = all[i];
      if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') continue;
      const attrs = el.attributes;
      for (let j = 0; j < attrs.length; j++) {
        const v = attrs[j].value;
        if (!v || v.length < 16 || v.length > 4000) continue;
        if (!/ai3\/ppt\//i.test(v)) continue;
        for (const u of urlsInValue(v)) addSlide(u);
      }
    }
    try {
      for (const im of doc.querySelectorAll('img')) {
        for (const a of ['src', 'data-src', 'data-original']) {
          const v = im.getAttribute(a);
          if (v) addSlide(v);
        }
      }
    } catch {
      /* ignore */
    }
  }

  function collectSlideNetwork(win) {
    try {
      for (const e of win.performance.getEntriesByType('resource') || []) {
        if (e.name && /ai3\/ppt\//i.test(e.name)) addSlide(e.name);
      }
    } catch {
      /* ignore */
    }
  }

  /** 同一个 uuid 的一组截图 = 一节课的板书，按时间排好、编号命名 */
  function buildSlideItems() {
    const groups = new Map();
    for (const s of slides.values()) {
      const g = s.path.split('/').slice(0, 5).join('/');
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g).push(s);
    }
    let best = [];
    for (const arr of groups.values()) if (arr.length > best.length) best = arr;
    if (!best.length) return [];
    best.sort((a, b) => a.ts - b.ts || a.path.localeCompare(b.path));
    const width = Math.max(3, String(best.length).length);
    return best.map((s, i) => {
      const ext = (s.path.split('.').pop() || 'jpg').toLowerCase();
      // 日期_序号：多节课下到同一个目录也不会互相覆盖，按名字排就是按时间排
      return {
        url: s.url,
        name: `${s.date}_${String(i + 1).padStart(width, '0')}.${ext}`,
        ext,
        kind: 'slide',
        seq: i + 1,
        source: 'slide',
      };
    });
  }

  /** 课程页里指向各节录播的链接（拿去一节一节抓） */
  function collectSessions(doc) {
    const out = [];
    const seen = new Set();
    try {
      for (const a of doc.querySelectorAll('a[href]')) {
        let u;
        try {
          u = new URL(a.href, location.href);
        } catch {
          continue;
        }
        if (!/livingroom/i.test(u.pathname + u.search)) continue;
        if (!u.searchParams.get('sub_id')) continue;
        const key = u.origin + u.pathname + '?course_id=' + (u.searchParams.get('course_id') || '') + '&sub_id=' + u.searchParams.get('sub_id');
        if (seen.has(key)) continue;
        seen.add(key);
        const text = (a.textContent || '').replace(/\s+/g, ' ').trim();
        out.push({ url: key, title: (a.title || text || '').slice(0, 60) });
        if (out.length >= 200) break;
      }
    } catch {
      /* ignore */
    }
    return out;
  }

  function scanDoc(doc, win, allowDocs, depth, out) {
    if (!doc || depth > 3) return;
    walkAttributes(doc, allowDocs);
    collectNetwork(win, allowDocs);
    walkSlides(doc);
    collectSlideNetwork(win);
    // 同源 iframe 递归
    let frames = [];
    try {
      frames = [...doc.querySelectorAll('iframe, frame')];
    } catch {
      frames = [];
    }
    for (const f of frames) {
      try {
        const fd = f.contentDocument;
        if (fd) scanDoc(fd, f.contentWindow, allowDocs, depth + 1, out);
      } catch {
        /* 跨域，交给那个 frame 自己的 content script */
      }
    }
  }

  async function autoScroll() {
    const total = document.documentElement ? document.documentElement.scrollHeight : 0;
    if (!total || total < window.innerHeight * 1.4) return;
    const step = Math.max(320, Math.floor(window.innerHeight * 0.85));
    for (let y = 0, i = 0; y < total + step && i < 60; y += step, i++) {
      window.scrollTo(0, y);
      await sleep(110);
    }
    window.scrollTo(0, 0);
    await sleep(200);
  }

  async function runScan(opts, scanId) {
    const allowDocs = !!opts.allowDocs;
    const isTop = window.top === window;

    if (isTop && opts.autoScroll) {
      try {
        await autoScroll();
      } catch {
        /* ignore */
      }
    }

    store.clear();
    slides.clear();
    scanDoc(document, window, allowDocs, 0, null);

    // 智能探测只在顶层跑，避免每个 iframe 都去打一遍
    if (isTop && opts.probe) {
      const suspects = collectSuspects(document, 15);
      const results = await Promise.all(
        suspects.map((s) => probeLink(s.url, allowDocs).catch(() => []))
      );
      results.forEach((arr, i) => {
        for (const r of arr) add(r.url, null, 'probe', { allowDocs });
        if (arr.length && suspects[i]) {
          for (const r of arr) {
            const item = store.get(norm(r.url));
            if (item && (!item.name || item.name === 'file.' + item.ext)) {
              const lbl = sanitizeName(suspects[i].label);
              if (lbl) item.name = lbl + '.' + item.ext;
            }
          }
        }
      });
    }

    const slideItems = buildSlideItems();
    const sessions = isTop ? collectSessions(document) : [];
    // 录播页：只有截图没有原件，就按“一页一张图”给出去
    const items = slideItems.length >= 3 ? slideItems : [...store.values()].concat(slideItems);
    // 顶层没结果时，把 frame 里的也报上来（frame 自己也会回消息，这里只是兜底）
    return {
      items,
      sessions,
      deck: slideItems.length >= 3,
      slideCount: slideItems.length,
      frameUrl: location.href,
      frameTitle: document.title,
      scanId,
    };
  }

  function debugInfo() {
    const links = [...document.querySelectorAll('a[href]')]
      .slice(0, 250)
      .map((a) => ({ text: (a.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80), href: a.href }));
    const attrs = [];
    for (const el of [...document.querySelectorAll('[data-url],[data-href],[data-src],[data-file],[data-id]')].slice(0, 300)) {
      const o = { tag: el.tagName };
      for (const a of el.attributes) o[a.name] = a.value.slice(0, 300);
      attrs.push(o);
    }
    slides.clear();
    scanDoc(document, window, false, 0, null);
    const slideItems = buildSlideItems();
    return {
      url: location.href,
      title: document.title,
      links,
      attrs,
      slideCount: slideItems.length,
      slides: slideItems.slice(0, 5).map((s) => s.url),
      sessions: collectSessions(document).length,
    };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || typeof msg !== 'object') return;

    if (msg.type === 'ping') {
      sendResponse({ ok: true, url: location.href });
      return;
    }

    if (msg.type === 'scan') {
      (async () => {
        let res;
        try {
          res = await runScan(msg.opts || {}, msg.scanId);
        } catch (e) {
          res = { items: [], error: String(e && e.message ? e.message : e) };
        }
        // 广播给 popup（popup 可能只收到第一个 sendResponse，所以走 runtime 消息）
        try {
          const p = chrome.runtime.sendMessage({
            type: 'scanResult',
            scanId: msg.scanId,
            items: res.items || [],
            sessions: res.sessions || [],
            deck: !!res.deck,
            slideCount: res.slideCount || 0,
            error: res.error || '',
            frameUrl: location.href,
            frameTitle: document.title,
          });
          if (p && typeof p.catch === 'function') p.catch(() => {});
        } catch {
          /* popup 已关 */
        }
        sendResponse({ ok: true, count: (res.items || []).length });
      })();
      return true; // 异步
    }

    if (msg.type === 'debug') {
      try {
        sendResponse({ ok: true, info: debugInfo() });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
    }
  });
})();
