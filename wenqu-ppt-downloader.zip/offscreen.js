/* 离屏文档：把一节课的截图抓下来，合成一个 PPTX 再下载。
   放这里是因为要 Blob / URL.createObjectURL，后台 service worker 没有这些。 */

let busy = false;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // 只接后台转进来的任务：弹窗也会广播同名消息，别抢着干
  if (!msg || msg.type !== 'offscreenDeck') return;
  if (busy) {
    sendResponse({ ok: false, error: '已经有一个合成任务在跑' });
    return;
  }
  build(msg).catch((e) => {
    busy = false;
    send({ type: 'pptxDone', ok: false, error: String((e && e.message) || e) });
  });
  sendResponse({ ok: true, started: true });
  return true;
});

function send(payload) {
  try {
    const p = chrome.runtime.sendMessage(payload);
    if (p && typeof p.catch === 'function') p.catch(() => {});
  } catch {
    /* ignore */
  }
}

function sanitize(name) {
  let s = String(name || '')
    .replace(/[\u0000-\u001f<>:"/\\|?*]/g, '_')
    .replace(/\s+/g, ' ')
    .replace(/^[. ]+|[. ]+$/g, '')
    .trim();
  if (!s) s = '课件';
  if (s.length > 90) s = s.slice(0, 90);
  return s;
}

function fnv(data) {
  let h = 0x811c9dc5;
  for (let i = 0; i < data.length; i++) {
    h ^= data[i];
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return h >>> 0;
}

async function fetchImage(url) {
  const resp = await fetch(url, { credentials: 'include', cache: 'force-cache' });
  if (!resp.ok) throw new Error('HTTP ' + resp.status);
  const buf = await resp.arrayBuffer();
  const ct = (resp.headers.get('content-type') || '').toLowerCase();
  let ext = 'jpg';
  if (ct.includes('png')) ext = 'png';
  else if (url && /\.png(\?|#|$)/i.test(url)) ext = 'png';
  return { data: new Uint8Array(buf), ext };
}

async function build(msg) {
  busy = true;
  const items = Array.isArray(msg.items) ? msg.items.filter((i) => i && i.url) : [];
  if (!items.length) throw new Error('没有要合成的图片');

  const total = items.length;
  const dropDup = msg.dedupe !== false;
  const images = [];
  let prevHash = -1;
  let failed = 0;
  let skipped = 0;

  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    try {
      const got = await fetchImage(it.url);
      const h = fnv(got.data);
      if (dropDup && h === prevHash) {
        skipped++;
      } else {
        prevHash = h;
        images.push({ data: got.data, ext: got.ext, descr: it.name || `第 ${images.length + 1} 页` });
      }
    } catch (e) {
      failed++;
    }
    if (i % 3 === 0 || i === items.length - 1) {
      send({
        type: 'pptxProgress',
        done: i + 1,
        total,
        pages: images.length,
        failed,
        skipped,
        name: it.name || '',
      });
    }
    if (msg.cancelled) break;
  }

  if (!images.length) throw new Error('一张图都没抓到');

  const bytes = PPTX.buildPptx(images, { title: msg.title || '' });
  const folder = String(msg.folder || '问渠学堂')
    .replace(/[\u0000-\u001f<>:"|?*]/g, '_')
    .split(/[\\/]+/)
    .map((p) => p.trim())
    .filter((p) => p && p !== '.' && p !== '..')
    .join('/');

  const base = sanitize(msg.title || '课件');
  const filename = (folder ? folder + '/' : '') + base + '.pptx';

  send({ type: 'pptxProgress', done: total, total, pages: images.length, failed, skipped, stage: 'saving' });

  const blob = new Blob([bytes], {
    type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  });
  const url = URL.createObjectURL(blob);
  try {
    const id = await new Promise((resolve, reject) => {
      chrome.downloads.download({ url, filename, saveAs: false, conflictAction: 'uniquify' }, (d) => {
        const err = chrome.runtime.lastError;
        if (err || d === undefined) reject(new Error((err && err.message) || '下载失败'));
        else resolve(d);
      });
    });
    setTimeout(() => URL.revokeObjectURL(url), 120000);
    busy = false;
    send({
      type: 'pptxDone',
      ok: true,
      filename,
      pages: images.length,
      bytes: bytes.length,
      failed,
      skipped,
      downloadId: id,
    });
  } catch (e) {
    // 离屏文档里调下载没成功，就把 blob 地址交给后台再试一次
    busy = false;
    send({
      type: 'pptxBlob',
      url,
      filename,
      pages: images.length,
      bytes: bytes.length,
      failed,
      skipped,
      error: String((e && e.message) || e),
    });
    setTimeout(() => URL.revokeObjectURL(url), 180000);
  }
}
