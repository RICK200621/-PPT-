/* 用最小 DOM 模拟跑一遍扫描逻辑，验证“找链接 + 取名 + 预检”这条链没坏。
 * 运行： node test/scan.test.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

class El {
  constructor(tag, attrs = {}, text = '') {
    this.tag = tag;
    this.attrs = attrs;
    this._text = text;
  }
  get tagName() {
    return this.tag.toUpperCase();
  }
  get className() {
    return this.attrs.class || '';
  }
  getAttribute(n) {
    return Object.prototype.hasOwnProperty.call(this.attrs, n) ? this.attrs[n] : null;
  }
  get attributes() {
    return Object.entries(this.attrs).map(([name, value]) => ({ name, value: String(value) }));
  }
  get textContent() {
    return this._text;
  }
  querySelectorAll() {
    return [];
  }
}

const courseUrl = 'https://lms.cdut.edu.cn/course/123/home';
const els = [
  new El('a', { href: '/mod/resource/file/%E7%AC%AC1%E7%AB%A0%E7%BB%AA%E8%AE%BA.pptx' }, '第1章 绪论 课件'),
  new El('div', { 'data-url': '/files/lecture-02.PPTX', class: 'file-item' }, '第二章'),
  new El('a', { href: '/view?id=88', title: '第三章 课件（PPT）' }, '第三章 课件（PPT）'),
  new El('img', { src: '/static/logo.png' }, ''),
  new El('a', { href: '/mod/resource/view?id=9' }, '课程大纲'),
];

const anchors = els.filter((e) => e.tag === 'a' && (e.attrs.href || e.attrs['data-href']));

const document = {
  baseURI: courseUrl,
  title: '第一章 课件 - 问渠学堂',
  documentElement: { scrollHeight: 900 },
  querySelectorAll(sel) {
    if (sel === '*') return els;
    if (sel === 'iframe, frame') return [];
    if (sel === 'a[href], [data-href], [role="button"]') {
      return els.filter((e) => e.attrs.href || e.attrs['data-href'] || e.attrs.role === 'button');
    }
    if (sel === 'a[href]') return anchors;
    if (sel === '[data-url],[data-href],[data-src],[data-file],[data-id]') {
      return els.filter((e) => e.attrs['data-url'] || e.attrs['data-file']);
    }
    return [];
  },
  createElement: (t) => new El(t),
  body: null,
};

const sent = [];
let handler = null;

const chrome = {
  runtime: {
    onMessage: { addListener: (fn) => (handler = fn) },
    sendMessage: (m) => {
      sent.push(m);
      return Promise.resolve();
    },
  },
};

const html =
  '<html><body><a href="/files/%E7%AC%AC%E5%9B%9B%E7%AB%A0.pptx">第四章 课件</a></body></html>';

const fetchStub = async (url) => {
  if (String(url).includes('/view?id=88')) {
    return new Response(html, { status: 200, headers: { 'content-type': 'text/html; charset=utf-8' } });
  }
  return new Response('', { status: 404 });
};

const sandbox = {
  window: {
    top: null,
    innerHeight: 800,
    scrollTo() {},
    scrollY: 0,
    __WQ_PPT_SCANNER__: false,
  },
  document,
  location: { href: courseUrl },
  performance: { getEntriesByType: () => [{ name: 'https://cdn.cdut.edu.cn/files/lecture-03.ppt' }] },
  chrome,
  fetch: fetchStub,
  URL,
  AbortSignal,
  setTimeout,
  clearTimeout,
  console,
};
sandbox.window.top = sandbox.window;
sandbox.window.document = document;
sandbox.window.location = sandbox.location;
sandbox.window.performance = sandbox.performance;

vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), sandbox, { filename: 'content.js' });

assert.ok(handler, 'content script 没注册监听器');

let replied = null;
handler({ type: 'scan', scanId: 's1', opts: { autoScroll: false, probe: true, allowDocs: false } }, null, (r) => {
  replied = r;
});

await new Promise((r) => setTimeout(r, 1500));

const result = sent.find((m) => m.type === 'scanResult');
assert.ok(result, '没有收到 scanResult');
const urls = result.items.map((i) => i.url);
const names = result.items.map((i) => i.name);

console.log('items:');
for (const it of result.items) console.log(`  [${it.source}] ${it.name}  <-  ${it.url}`);

const has = (frag) => urls.some((u) => u.includes(frag));
assert.ok(has('study.ppt') || has('.ppt'), '缺 performance 里的 ppt');
assert.ok(has('lecture-02.PPTX'), '缺 data-url 的 pptx');
assert.ok(has('第四章') || has('.pptx'), '缺 probe 找到的 pptx');
assert.ok(!urls.some((u) => u.endsWith('logo.png')), '把 png 也收进来了');
assert.ok(!urls.some((u) => u.includes('/view?id=9')), '把大纲页也收进来了');

const first = result.items.find((i) => i.url.includes('lecture-02'));
assert.ok(first && /\.pptx$/.test(first.name), 'data-url 那条没补上扩展名');

assert.ok(replied && replied.ok, '同步回调没响应');

console.log('\ncontent.js 扫描逻辑 OK');

/* ---------- background 的取名/目录逻辑 ---------- */
let chromeBg = {
  runtime: { onMessage: { addListener: () => {} }, lastError: undefined },
  downloads: { onChanged: { addListener: () => {} }, download: () => {} },
  action: { setBadgeText() {}, setBadgeBackgroundColor() {} },
};

const bgSandbox = {
  chrome: chromeBg,
  URL,
  AbortSignal,
  setTimeout,
  clearTimeout,
  console,
  fetch: async () => {
    throw new Error('no network');
  },
};
vm.createContext(bgSandbox);
const bgSrc =
  fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8') +
  '\n;globalThis.__t = { pickName, sanitizeFolder, filenameFromDisposition, nameFromUrl, sanitizeName };';
vm.runInContext(bgSrc, bgSandbox, { filename: 'background.js' });
const t = bgSandbox.__t;

assert.equal(
  t.filenameFromDisposition(`attachment; filename="lecture 1.pptx"`),
  'lecture 1.pptx'
);
assert.equal(
  t.filenameFromDisposition(`attachment; filename*=UTF-8''%E8%AF%BE%E4%BB%B6.pptx`),
  '课件.pptx'
);
assert.equal(t.sanitizeFolder('问渠学堂/第一章: 绪论'), '问渠学堂/第一章_ 绪论');
assert.equal(t.sanitizeFolder('../../etc'), 'etc');
assert.equal(t.pickName({ name: '', ext: 'pptx' }, 'https://x/y/abc.pptx', null), 'abc.pptx');
assert.equal(t.pickName({ name: '第三章 课件', ext: 'pptx' }, 'https://x/y/download?id=3', null), '第三章 课件.pptx');
assert.equal(
  t.pickName({ name: '', ext: 'ppt' }, 'https://x/y/get?id=3', { filename: '真名.PPT' }),
  '真名.PPT'
);
assert.equal(t.nameFromUrl('https://x/a.pptx?x=1'), 'a.pptx');

console.log('background.js 取名逻辑 OK');
console.log('\n全部通过');

/* ---------- 录播截图模式（问渠学堂 livingroom） ---------- */
{
  const base = 'https://video.wqxt.cdut.edu.cn/ai3/ppt/20260915/3ede59a4-9b07-4701-a24b-b28a788e4ac1/';
  const el2 = (src) => new El('img', { 'data-src': src, src: './static/img/loading.png' }, '');
  const els2 = [
    el2(base + '5690720.jpg'),
    el2(base + '0.jpg'),
    el2('http://video.wqxt.cdut.edu.cn/ai3/ppt/20260915/3ede59a4-9b07-4701-a24b-b28a788e4ac1/4360.jpg'),
    el2(base + '0.jpg'), // 重复
    el2('https://video.wqxt.cdut.edu.cn/ai3/ppt/20260914/ccd889ca-5166-43f1-b5fc-86b8d07f59e8/s_1789380007000.jpg'),
  ];
  const doc2 = {
    baseURI: 'https://classroom.wqxt.cdut.edu.cn/livingroom?course_id=1&sub_id=2',
    title: '水污染控制工程2026-09-14第7-8节',
    documentElement: { scrollHeight: 800 },
    querySelectorAll(sel) {
      if (sel === '*') return els2;
      if (sel === 'img') return els2;
      return [];
    },
  };
  const sent2 = [];
  let handler2 = null;
  const chrome2 = {
    runtime: {
      onMessage: { addListener: (fn) => (handler2 = fn) },
      sendMessage: (m) => {
        sent2.push(m);
        return Promise.resolve();
      },
    },
  };
  const sb2 = {
    window: { top: null, innerHeight: 800, scrollTo() {}, __WQ_PPT_SCANNER__: false },
    document: doc2,
    location: { href: doc2.baseURI },
    performance: { getEntriesByType: () => [] },
    chrome: chrome2,
    fetch: async () => new Response('', { status: 404 }),
    URL,
    AbortSignal,
    setTimeout,
    clearTimeout,
    console,
  };
  sb2.window.top = sb2.window;
  vm.createContext(sb2);
  vm.runInContext(fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), sb2, { filename: 'content.js' });

  handler2({ type: 'scan', scanId: 's2', opts: { autoScroll: false, probe: false, allowDocs: false } }, null, () => {});
  await new Promise((r) => setTimeout(r, 400));
  const res2 = sent2.find((m) => m.type === 'scanResult');
  assert.ok(res2, '录播页没返回 scanResult');
  assert.equal(res2.deck, true, '没识别成录播截图');
  assert.equal(res2.items.length, 3, '截图数量不对（应该去掉重复、忽略别的 uuid）: ' + res2.items.length);
  assert.equal(res2.items[0].name, '20260915_001.jpg');
  assert.ok(res2.items[0].url.startsWith('https://'), 'http 地址没统一成 https');
  assert.ok(res2.items[0].url.endsWith('/0.jpg'), '排序不对：' + res2.items[0].url);
  assert.ok(res2.items[2].url.endsWith('/5690720.jpg'), '排序不对：' + res2.items[2].url);
  assert.deepEqual(
    res2.items.map((i) => i.name),
    ['20260915_001.jpg', '20260915_002.jpg', '20260915_003.jpg']
  );
  console.log('录播截图模式 OK（3 张，按时间排序，命名 日期_序号）');
}

