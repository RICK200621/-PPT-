"""检查一个 pptx 的内部一致性：rels 目标是否都存在、每个部件是否都有内容类型。

用法： python tools/check_pptx.py <文件.pptx>
这是给「本地没装 PowerPoint / LibreOffice」时兜底用的，比只看 python-pptx 能不能打开更严一点。
"""

import posixpath
import sys
import zipfile
import xml.etree.ElementTree as ET

REL_NS = "{http://schemas.openxmlformats.org/package/2006/relationships}"
CT_NS = "{http://schemas.openxmlformats.org/package/2006/content-types}"


def main(path):
    z = zipfile.ZipFile(path)
    names = set(z.namelist())

    ct = ET.fromstring(z.read("[Content_Types].xml"))
    defaults = {e.get("Extension").lower(): e.get("ContentType") for e in ct.findall(CT_NS + "Default")}
    overrides = {e.get("PartName"): e.get("ContentType") for e in ct.findall(CT_NS + "Override")}

    problems = []

    for name in sorted(names):
        if name == "[Content_Types].xml" or name.endswith("/"):
            continue
        if "/" + name in overrides:
            continue
        ext = name.rsplit(".", 1)[-1].lower()
        if ext in defaults:
            continue
        problems.append(f"没有内容类型: {name}")

    for name in sorted(n for n in names if n.endswith(".rels")):
        base = posixpath.dirname(posixpath.dirname(name))
        root = ET.fromstring(z.read(name))
        for rel in root.findall(REL_NS + "Relationship"):
            if rel.get("TargetMode") == "External":
                continue
            target = rel.get("Target")
            resolved = target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join(base, target))
            if resolved not in names:
                problems.append(f"{name} -> 缺失 {resolved}")

    pres = ET.fromstring(z.read("ppt/presentation.xml"))
    pns = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
    rns = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    pres_rels = ET.fromstring(z.read("ppt/_rels/presentation.xml.rels"))
    rel_map = {r.get("Id"): r.get("Target") for r in pres_rels.findall(REL_NS + "Relationship")}

    for ref in pres.iter():
        rid = ref.get(rns + "id")
        if rid and rid not in rel_map:
            problems.append(f"presentation.xml 引用了不存在的 {rid}")

    slides = pres.findall(f".//{pns}sldId")
    print(f"部件 {len(names)} 个，幻灯片 {len(slides)} 页")
    if problems:
        print("发现问题：")
        for p in problems[:40]:
            print("  -", p)
        return 1
    print("结构检查通过：rels 目标齐全、内容类型齐全")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
