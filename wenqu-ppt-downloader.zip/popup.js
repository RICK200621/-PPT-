/* 问渠学堂 PPT 抓取 — 弹窗逻辑 */

const $ = (id) => document.getElementById(id);

const listEl = $('list');
const countEl = $('count');
const statusEl = $('status');
const pageTitleEl = $('pageTitle');
const folderEl = $('folder');
const manualEl = $('manualUrl');

let items = new Map(); // url -> item
let tab = null;
let scanning = false;
let deck = false;
let sessions = [];
let finishedTimer = null;
let hardTimer = null;
let lastDeckItems = null;

/* ---------------- 小工具 ---------------- */

function setStatus(text, kind = '') {
  statusEl.textContent = text;
  statusEl.className = 'status' + (kind ? ' ' + kind : '');
}

function sanitizeName(name) {
  let s = String(name || '')
    .replace(/[\u0000-\u001f<>:"/\\|?*]/g, '_')
    .replace(/\s+/g, ' ')
    .trim();
  s = s.replace(/^[. ]+/, '').replace(/[. ]+$/, '');
  return s || 'file';
}

function shortTitle(t) {
  return sanitizeName(String(t || '').replace(/\s*[-_|].*(问渠学堂|砚湖易办|成都理工).*$/, '')).slice(0, 40);
}

function prettyUrl(u) {
  try {
    const x = new URL(u);
    return x.hostname + decodeURIComponent(x.pathname);
  } catch {
    return u;
  }
}

/* ---------------- 列表渲染 ---------------- */

const SOURCE_LABEL = { attr: '页面', network: '请求', probe: '探测', manual: '手填', slide: '截图' };

function render() {
  const arr = [...items.values()].sort((a, b) => {
    const sa = a.kind === 'slide' ? a.seq : -1;
    const sb = b.kind === 'slide' ? b.seq : -1;
    if (sa >= 0 && sb >= 0) return sa - sb;
    if (sa >= 0) return -1;
    if (sb >= 0) return 1;
    return 0;
  });
  countEl.textContent = deck ? arr.length + ' 张截图' : arr.length + ' 个文件';

  listEl.innerHTML = '';
  const frag = document.createDocumentFragment();
  for (const it of arr) {
    const li = document.createElement('li');
    li.dataset.url = it.url;

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = it.checked !== false;
    cb.addEventListener('change', () => {
      it.checked = cb.checked;
      syncCheckAll();
    });

    const meta = document.createElement('div');
    meta.className = 'meta';

    const name = document.createElement('div');
    name.className = 'fname';
    name.textContent = it.name || prettyUrl(it.url);
    if (it.source && SOURCE_LABEL[it.source]) {
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.textContent = SOURCE_LABEL[it.source];
      name.appendChild(tag);
    }

    const url = document.createElement('div');
    url.className = 'furl';
    url.textContent = prettyUrl(it.url);

    meta.append(name, url);
    li.append(cb, meta);
    frag.appendChild(li);
  }
  listEl.appendChild(frag);
  syncCheckAll();
}

function syncCheckAll() {
  const boxes = [...listEl.querySelectorAll('input[type="checkbox"]')];
  const checked = boxes.filter((b) => b.checked).length;
  const all = $('checkAll');
  all.checked = boxes.length > 0 && checked === boxes.length;
  all.indeterminate = checked > 0 && checked < boxes.length;
}

function addItem(raw) {
  if (!raw || !raw.url) return;
  const url = String(raw.url);
  const prev = items.get(url);
  if (prev) {
    if (!prev.name && raw.name) prev.name = raw.name;
    return;
  }
  items.set(url, {
    url,
    name: raw.name || '',
    ext: raw.ext || '',
    source: raw.source || 'attr',
    kind: raw.kind || '',
    seq: raw.seq || 0,
    checked: true,
  });
}

/* ---------------- 扫描 ---------------- */

function showDeckHint(n) {
  $('deckHint').classList.remove('hidden');
  const on = $('optPptx').checked;
  $('deckText').textContent = on
    ? `这是录播画面截图（${n} 页），下载时直接合成一个 PPTX`
    : `这是录播画面截图（${n} 页），将下载 ${n} 张图片`;
}

function deckName() {
  const base = shortTitle(tab && tab.title);
  return base || '课件';
}

function scanOptions() {
  return {
    autoScroll: $('optScroll').checked,
    probe: $('optProbe').checked,
    allowDocs: $('optDocs').checked,
  };
}

async function startScan() {
  if (!tab || scanning) return;
  if (!/^https?:/i.test(tab.url || '')) {
    setStatus('这个页面不能扫描', 'err');
    return;
  }

  scanning = true;
  items.clear();
  deck = false;
  sessions = [];
  $('deckHint').classList.add('hidden');
  $('courseBox').classList.add('hidden');
  render();
  $('scanBtn').disabled = true;
  setStatus('扫描中…');

  const scanId = 'scan_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  window.__scanId = scanId;

  clearTimeout(finishedTimer);
  clearTimeout(hardTimer);
  hardTimer = setTimeout(finishScan, 16000);

  try {
    await chrome.tabs.sendMessage(tab.id, {
      type: 'scan',
      opts: scanOptions(),
      scanId,
    });
  } catch (e) {
    clearTimeout(hardTimer);
    scanning = false;
    $('scanBtn').disabled = false;
    render();
    setStatus('没连上页面脚本，刷新一下课程页再试', 'err');
    return;
  }

  // 各 frame 陆续回消息，静默 1.2s 后收尾
  finishedTimer = setTimeout(finishScan, 1200);
}

function finishScan() {
  clearTimeout(finishedTimer);
  clearTimeout(hardTimer);
  if (!scanning) return;
  scanning = false;
  $('scanBtn').disabled = false;
  render();
  const n = items.size;
  if (!n) setStatus('没找到，先手动滚动页面再扫一次', 'warn');
  else if (deck) setStatus(`找到 ${n} 张截图`, 'ok');
  else setStatus(`找到 ${n} 个文件`, 'ok');
}

/* ---------------- 下载 ---------------- */

async function downloadSelected() {
  const picked = [...items.values()].filter((i) => i.checked !== false);
  if (!picked.length) {
    setStatus('先勾选文件', 'warn');
    return;
  }
  const folder = folderEl.value.trim() || '问渠学堂';

  const onlySlides = picked.every((i) => i.kind === 'slide');
  if (onlySlides && $('optPptx').checked) {
    $('dlBtn').disabled = true;
    setStatus(`合成 PPTX… 0/${picked.length}`);
    lastDeckItems = $('optKeep').checked ? picked.slice().sort((a, b) => a.seq - b.seq) : null;
    try {
      await chrome.runtime.sendMessage({
        type: 'deckPptx',
        items: picked
          .slice()
          .sort((a, b) => a.seq - b.seq)
          .map((i) => ({ url: i.url, name: i.name })),
        folder,
        title: deckName(),
        dedupe: true,
        keepImages: $('optKeep').checked,
      });
    } catch (e) {
      $('dlBtn').disabled = false;
      setStatus('后台没响应，重开一下弹窗', 'err');
    }
    return;
  }

  $('dlBtn').disabled = true;
  setStatus(`开始下载 ${picked.length} 个…`);

  try {
    await chrome.runtime.sendMessage({
      type: 'downloadBatch',
      items: picked.map((i) => ({ url: i.url, name: i.name, ext: i.ext, kind: i.kind })),
      folder,
      precheck: !deck,
    });
  } catch (e) {
    $('dlBtn').disabled = false;
    setStatus('后台没响应，重开一下弹窗', 'err');
  }
}

function humanBytes(n) {
  if (!n) return '';
  if (n > 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB';
  return Math.round(n / 1024) + ' KB';
}

/* ---------------- 事件 ---------------- */

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== 'object') return;

  if (msg.type === 'scanResult') {
    if (msg.scanId && window.__scanId && msg.scanId !== window.__scanId) return;
    if (msg.error) {
      setStatus('扫描出错：' + msg.error, 'err');
      return;
    }
    if (msg.deck && msg.slideCount >= 3) {
      deck = true;
      showDeckHint(msg.slideCount);
    }
    if (Array.isArray(msg.sessions) && msg.sessions.length) {
      const known = new Set(sessions.map((s) => s.url));
      for (const s of msg.sessions) if (!known.has(s.url)) sessions.push(s);
      $('courseText').textContent = `识别到 ${sessions.length} 节录播`;
      $('courseBox').classList.remove('hidden');
    }
    let added = 0;
    for (const it of msg.items || []) {
      const before = items.size;
      addItem(it);
      if (items.size > before) added++;
    }
    if (added) {
      render();
      setStatus(`扫描中… 已有 ${items.size} 个`);
    }
    if (scanning) {
      clearTimeout(finishedTimer);
      finishedTimer = setTimeout(finishScan, 1200);
    }
    return;
  }

  if (msg.type === 'courseProgress' && msg.job) {
    const j = msg.job;
    if (msg.phase === 'open') {
      setStatus(`抓第 ${msg.index}/${msg.total} 节…${msg.title ? ' ' + shortTitle(msg.title) : ''}`);
    } else if (msg.phase === 'ok') {
      setStatus(`第 ${msg.index}/${msg.total} 节 OK（${msg.count} 张）`, 'ok');
    } else if (msg.phase === 'download') {
      setStatus(`抓取结束，共 ${msg.count} 张，开始下载…`, 'ok');
    } else if (j.sessionTotal) {
      setStatus(`进度 ${j.sessionDone}/${j.sessionTotal}（失败 ${j.sessionFail}）`);
    }
    return;
  }

  if (msg.type === 'progress' && msg.job) {
    const j = msg.job;
    setStatus(`下载中 ${j.done}/${j.total}（成功 ${j.ok}，跳过 ${j.skipped}，失败 ${j.failed}）`);
    return;
  }

  if (msg.type === 'pptxProgress') {
    const extra = msg.failed ? `，失败 ${msg.failed}` : '';
    const skip = msg.skipped ? `，去重 ${msg.skipped}` : '';
    if (msg.stage === 'saving') setStatus(`正在保存 PPTX（${msg.pages} 页）…`, 'ok');
    else setStatus(`合成中 ${msg.done}/${msg.total}，已收 ${msg.pages} 页${skip}${extra}`);
    return;
  }

  if (msg.type === 'pptxDone') {
    if (!msg.ok) {
      setStatus('合成失败：' + (msg.error || '未知原因'), 'err');
      return;
    }
    const bits = [`已经存成 PPTX：${msg.filename || ''}`];
    if (msg.pages) bits.push(`${msg.pages} 页`);
    if (msg.bytes) bits.push(humanBytes(msg.bytes));
    if (msg.skipped) bits.push(`去重 ${msg.skipped}`);
    if (msg.failed) bits.push(`没抓到 ${msg.failed}`);
    if (msg.part) bits[0] = `第 ${msg.part} 份：${msg.filename || ''}`;
    setStatus(bits.join('，'), msg.failed ? 'warn' : 'ok');
    if (msg.part && !/^1\//.test(msg.part)) return;
    $('dlBtn').disabled = false;

    if ($('optKeep').checked && lastDeckItems && lastDeckItems.length) {
      chrome.runtime
        .sendMessage({
          type: 'downloadBatch',
          items: lastDeckItems.map((i) => ({ url: i.url, name: i.name, ext: i.ext, kind: 'slide' })),
          folder: folderEl.value.trim() || '问渠学堂',
          precheck: false,
        })
        .catch(() => {});
      lastDeckItems = null;
    }
    return;
  }

  if (msg.type === 'jobDone' && msg.job) {
    const j = msg.job;
    $('dlBtn').disabled = false;
    $('courseBtn').disabled = false;
    if (msg.pptx && msg.pptx.ok) return; // 让 pptxDone 的文案留在状态栏
    if (msg.error) {
      setStatus('出错了：' + msg.error, 'err');
      return;
    }
    const parts = [`完成：成功 ${j.ok}`];
    if (j.skipped) parts.push(`跳过 ${j.skipped}`);
    if (j.failed) parts.push(`失败 ${j.failed}`);
    setStatus(parts.join('，'), j.failed ? 'warn' : 'ok');
    return;
  }
});

$('scanBtn').addEventListener('click', startScan);
$('dlBtn').addEventListener('click', downloadSelected);

$('courseBtn').addEventListener('click', async () => {
  if (!sessions.length) return;
  const folder = folderEl.value.trim() || '问渠学堂';
  $('courseBtn').disabled = true;
  $('dlBtn').disabled = true;
  setStatus(`逐节抓取 ${sessions.length} 节，别关浏览器…`);
  try {
    await chrome.runtime.sendMessage({
      type: 'courseScan',
      sessions: sessions.map((s) => ({ url: s.url, title: s.title })),
      folder,
      title: deckName(),
      pptx: $('optPptx').checked,
      dedupe: true,
      keepImages: $('optKeep').checked,
    });
  } catch (e) {
    setStatus('后台没响应，重开一下弹窗', 'err');
    $('courseBtn').disabled = false;
    $('dlBtn').disabled = false;
  }
});

$('copyUrlsBtn').addEventListener('click', async () => {
  const urls = [...items.values()]
    .filter((i) => i.kind === 'slide')
    .sort((a, b) => a.seq - b.seq)
    .map((i) => i.url);
  if (!urls.length) {
    setStatus('还没有截图地址', 'warn');
    return;
  }
  await copyText(urls.join('\n'));
  setStatus(`已复制 ${urls.length} 条地址，存成 txt 给 slides2pptx.py 用`, 'ok');
});

$('checkAll').addEventListener('change', (e) => {
  const on = e.target.checked;
  for (const cb of listEl.querySelectorAll('input[type="checkbox"]')) cb.checked = on;
  for (const it of items.values()) it.checked = on;
});

$('addBtn').addEventListener('click', () => {
  const raw = manualEl.value.trim();
  if (!raw) return;
  let url = raw;
  try {
    url = new URL(raw, tab && tab.url ? tab.url : undefined).href;
  } catch {
    setStatus('链接看着不对', 'err');
    return;
  }
  const ext = (url.match(/\.([a-z0-9]{2,5})(?:$|[?#])/i) || [])[1] || '';
  addItem({ url, name: '', ext: ext.toLowerCase(), source: 'manual' });
  manualEl.value = '';
  render();
  setStatus(`已添加，共 ${items.size} 个`, 'ok');
});

manualEl.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('addBtn').click();
});

$('debugBtn').addEventListener('click', async () => {
  if (!tab) return;
  try {
    const res = await chrome.tabs.sendMessage(tab.id, { type: 'debug' }, { frameId: 0 });
    const payload = JSON.stringify(
      { title: tab.title, url: tab.url, info: res && res.info, found: [...items.values()] },
      null,
      2
    );
    await copyText(payload);
    setStatus('调试信息已复制，粘给我就行', 'ok');
  } catch (e) {
    setStatus('复制失败：' + e.message, 'err');
  }
});

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return;
  } catch {
    /* 退回 execCommand */
  }
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  document.execCommand('copy');
  ta.remove();
}

/* ---------------- 初始化 ---------------- */

async function init() {
  const saved = await chrome.storage.local.get(['optScroll', 'optProbe', 'optDocs', 'optPptx', 'optKeep', 'folder']);
  if (saved.optScroll !== undefined) $('optScroll').checked = !!saved.optScroll;
  if (saved.optProbe !== undefined) $('optProbe').checked = !!saved.optProbe;
  if (saved.optDocs !== undefined) $('optDocs').checked = !!saved.optDocs;
  if (saved.optPptx !== undefined) $('optPptx').checked = !!saved.optPptx;
  if (saved.optKeep !== undefined) $('optKeep').checked = !!saved.optKeep;

  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  tab = t || null;

  if (tab) {
    pageTitleEl.textContent = tab.title || tab.url || '';
    pageTitleEl.title = tab.url || '';
    const course = shortTitle(tab.title);
    folderEl.value = saved.folder || (course ? '问渠学堂/' + course : '问渠学堂');
  }

  for (const id of ['optScroll', 'optProbe', 'optDocs', 'optPptx', 'optKeep']) {
    $(id).addEventListener('change', saveOpts);
  }
  $('optPptx').addEventListener('change', () => {
    if (deck) showDeckHint(items.size);
  });
  folderEl.addEventListener('change', saveOpts);

  if (tab && /^https?:/i.test(tab.url || '')) startScan();
  else setStatus('打开问渠学堂的课程页再点这里', 'warn');
}

function saveOpts() {
  chrome.storage.local.set({
    optScroll: $('optScroll').checked,
    optProbe: $('optProbe').checked,
    optDocs: $('optDocs').checked,
    optPptx: $('optPptx').checked,
    optKeep: $('optKeep').checked,
    folder: folderEl.value.trim(),
  });
}

init();
