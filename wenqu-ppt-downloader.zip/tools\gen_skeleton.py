#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""从 python-pptx 生成的空白模板里抽出最小骨架，写成扩展用的 pptx-skeleton.js。

只用跑一次（或者模板换了再跑）：
    python tools/gen_skeleton.py
"""

import io
import json
import os
import re
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
REF = os.path.join(os.environ.get("TEMP", "."), "pptxref", "ref.pptx")


def main():
    if not os.path.exists(REF):
        print("找不到模板 {}，先用 python-pptx 生成一个两页的 ref.pptx".format(REF))
        return 2

    z = zipfile.ZipFile(REF)

    def read(name):
        return z.read(name).decode("utf-8")

    master = read("ppt/slideMasters/slideMaster1.xml")
    # 只留第一个版式
    master = re.sub(
        r"<p:sldLayoutIdLst>.*?</p:sldLayoutIdLst>",
        '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>',
        master,
        flags=re.S,
    )
    # 版式统一改名成 slideLayout1
    layout = read("ppt/slideLayouts/slideLayout7.xml")
    theme = read("ppt/theme/theme1.xml")

    rels_head = (
        "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>\n"
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    )
    master_rels = (
        rels_head
        + '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
        + '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/>'
        + "</Relationships>"
    )
    layout_rels = (
        rels_head
        + '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/>'
        + "</Relationships>"
    )

    fixed = {
        "ppt/slideMasters/slideMaster1.xml": master,
        "ppt/slideMasters/_rels/slideMaster1.xml.rels": master_rels,
        "ppt/slideLayouts/slideLayout1.xml": layout,
        "ppt/slideLayouts/_rels/slideLayout1.xml.rels": layout_rels,
        "ppt/theme/theme1.xml": theme,
    }

    out = io.open(os.path.join(ROOT, "pptx-skeleton.js"), "w", encoding="utf-8", newline="\n")
    out.write("/* 由 tools/gen_skeleton.py 生成，别手改。里面是 PPTX 的固定部件。 */\n")
    out.write("const PPTX_FIXED = {\n")
    for k, v in fixed.items():
        out.write("  {}: {},\n".format(json.dumps(k), json.dumps(v, ensure_ascii=False)))
    out.write("};\n")
    out.close()

    size = os.path.getsize(os.path.join(ROOT, "pptx-skeleton.js"))
    print("写好 pptx-skeleton.js（{} 字节）".format(size))
    return 0


if __name__ == "__main__":
    sys.exit(main())
