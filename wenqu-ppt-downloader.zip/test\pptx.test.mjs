/* 生成 PPTX 的离线测试：在 Node 里跑一遍 builder，再用 python-pptx 验结果。
   node test/pptx.test.mjs */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';

const ROOT = path.dirname(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')));
const ctx = vm.createContext({ console, TextEncoder, TextDecoder, DataView, Uint8Array, Uint32Array });

for (const f of ['pptx-skeleton.js', 'pptx-builder.js']) {
  vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), ctx, { filename: f });
}

const PPTX = ctx.PPTX;
assert.ok(PPTX, 'builder 没挂到全局');
assert.equal(PPTX.crc32(new TextEncoder().encode('123456789')).toString(16), 'cbf43926', 'CRC32 算错');

const img = fs.readFileSync(path.join(ROOT, '..', 'slides-sample', 'slide_0001.jpg'));
const images = [
  { data: new Uint8Array(img), ext: 'jpg', descr: '第一页' },
  { data: new Uint8Array(img), ext: 'jpg', descr: '第二页' },
  { data: new Uint8Array(img), ext: 'jpg', descr: '第三页' },
];

const bytes = PPTX.buildPptx(images, { title: '测试' });
assert.ok(bytes.length > img.length * 3, '产物太小');
const out = path.join(ROOT, '..', 'pptx-test-out.pptx');
fs.writeFileSync(out, Buffer.from(bytes));
console.log(`写出 ${out}（${bytes.length} 字节）`);

// 用 python-pptx 打开验证：页数、每页图片、16:9
const py = `import sys, io
from pptx import Presentation
p = Presentation(sys.argv[1])
print("slides", len(p.slides))
print("size", p.slide_width, p.slide_height)
for i, s in enumerate(p.slides, 1):
    pics = [sh for sh in s.shapes if sh.shape_type == 13]
    print("slide", i, "pics", len(pics), "img_bytes", len(pics[0].image.blob) if pics else 0)
print("title", p.core_properties.title or "")
`;
const pyExe = process.env.WQ_PY || 'python';
const res = execFileSync(pyExe, ['-c', py, out], { encoding: 'utf8' });
console.log(res.trim());
for (const line of res.trim().split(/\r?\n/).map((l) => l.trim())) {
  if (line.startsWith('slides ')) assert.equal(line, 'slides 3');
  if (line.startsWith('size ')) assert.equal(line, 'size 12192000 6858000');
  if (line.startsWith('slide ')) assert.ok(/pics 1 img_bytes \d+/.test(line), '每页应有一张图: ' + line);
}
console.log('\nPPTX 生成 OK（3 页，每页一张图，16:9）');
