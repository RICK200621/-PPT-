/* 问渠学堂 PPT 抓取 — 后台：预检 + 批量下载 */

const DEFAULT_FOLDER = '问渠学堂';

const MIME_EXT = {
  'application/vnd.ms-powerpoint': 'ppt',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
  'application/vnd.openxmlformats-officedocument.presentationml.slideshow': 'ppsx',
  'application/pdf': 'pdf',
  'application/msword': 'doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
  'application/vnd.ms-excel': 'xls',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
  'application/zip': 'zip',
  'application/x-zip-compressed': 'zip',
};

const EXT_RE = /\.([a-z0-9]{2,5})$/i;

let job = idleJob();

function idleJob() {
  return { running: false, total: 0, done: 0, ok: 0, skipped: 0, failed: 0, cancelled: false, current: '', phase: '', log: [] };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ---------------- 文件名处理 ---------------- */

function filenameFromDisposition(cd) {
  if (!cd) return '';
  let m = cd.match(/filename\*\s*=\s*([^;]+)/i);
  if (m) {
    let v = m[1].trim().replace(/^["']|["']$/g, '');
    v = v.replace(/^UTF-8''/i, '');
    try {
      return decodeURIComponent(v);
    } catch {
      return v;
    }
  }
  m = cd.match(/filename\s*=\s*("?)([^";]+)\1/i);
  if (m) {
    let v = m[2].trim();
    if (/%[0-9A-Fa-f]{2}/.test(v)) {
      try {
        v = decodeURIComponent(v);
      } catch {
        /* 保持原样 */
      }
    }
    return v;
  }
  return '';
}

function sanitizeName(name) {
  let s = String(name || '')
    .replace(/[\u0000-\u001f<>:"/\\|?*]/g, '_')
    .replace(/\s+/g, ' ')
    .trim();
  s = s.replace(/^[. ]+/, '').replace(/[. ]+$/, '');
  if (!s) s = 'file';
  if (s.length > 120) {
    const dot = s.lastIndexOf('.');
    s = dot > 0 ? s.slice(0, 100) + s.slice(dot) : s.slice(0, 120);
  }
  return s;
}

function sanitizeFolder(folder) {
  const parts = String(folder || DEFAULT_FOLDER)
    .replace(/[\u0000-\u001f<>:"|?*]/g, '_')
    .split(/[\\/]+/)
    .map((p) => p.replace(/\s+/g, ' ').replace(/^[. ]+|[. ]+$/g, '').trim())
    .filter((p) => p && p !== '.' && p !== '..');
  return parts.length ? parts.join('/') : DEFAULT_FOLDER;
}

function nameFromUrl(url) {
  try {
    const u = new URL(url);
    const last = decodeURIComponent(u.pathname.split('/').filter(Boolean).pop() || '');
    if (last && EXT_RE.test(last)) return last;
    for (const key of ['fileName', 'filename', 'name', 'title', 'realName', 'attname', 'file']) {
      const v = u.searchParams.get(key);
      if (v && EXT_RE.test(v)) return decodeURIComponent(v.split('/').pop() || v);
    }
    return last;
  } catch {
    return '';
  }
}

function pickName(item, url, probed) {
  let name = sanitizeName(probed && probed.filename ? probed.filename : item.name || '');
  if (!name || !EXT_RE.test(name)) {
    const fromUrl = sanitizeName(nameFromUrl(url));
    if (fromUrl && EXT_RE.test(fromUrl)) name = fromUrl;
    else if (name) {
      const ext = (probed && MIME_EXT[(probed.contentType || '').split(';')[0].trim()]) || item.ext || 'pptx';
      name = name + '.' + ext;
    } else {
      const ext = (probed && MIME_EXT[(probed.contentType || '').split(';')[0].trim()]) || item.ext || 'pptx';
      name = '课件.' + ext;
    }
  }
  return sanitizeName(name);
}

/* ---------------- 预检 ---------------- */

async function probe(url) {
  const init = { credentials: 'include', redirect: 'follow' };
  let resp = null;
  try {
    resp = await fetch(url, {
      ...init,
      method: 'HEAD',
      signal: AbortSignal.timeout(8000),
    });
  } catch {
    resp = null;
  }
  if (!resp || !resp.ok) {
    try {
      resp = await fetch(url, {
        ...init,
        method: 'GET',
        headers: { Range: 'bytes=0-0' },
        signal: AbortSignal.timeout(8000),
      });
    } catch {
      resp = null;
    }
  }
  if (!resp) return { kind: 'unknown' };
  const ct = (resp.headers.get('content-type') || '').toLowerCase();
  const filename = filenameFromDisposition(resp.headers.get('content-disposition') || '');
  if (ct.includes('text/html') || ct.includes('application/json')) {
    return { kind: 'html', contentType: ct, filename };
  }
  if (!resp.ok) return { kind: 'unknown', contentType: ct, filename };
  return { kind: 'file', contentType: ct, filename };
}

/* ---------------- 下载 ---------------- */

function downloadP(url, filename) {
  return new Promise((resolve, reject) => {
    chrome.downloads.download({ url, filename, conflictAction: 'uniquify', saveAs: false }, (id) => {
      const err = chrome.runtime.lastError;
      if (err || id === undefined) reject(new Error((err && err.message) || '下载失败'));
      else resolve(id);
    });
  });
}

function broadcast(msg) {
  try {
    chrome.runtime.sendMessage(msg).catch(() => {});
  } catch {
    /* popup 已关闭 */
  }
}

function setBadge(text) {
  try {
    chrome.action.setBadgeBackgroundColor({ color: '#2563eb' });
    chrome.action.setBadgeText({ text: text || '' });
  } catch {
    /* ignore */
  }
}

async function runBatch(msg) {
  if (job.running) return { ok: false, error: '已有任务在跑' };
  const items = Array.isArray(msg.items) ? msg.items.filter((i) => i && i.url) : [];
  if (!items.length) return { ok: false, error: '没有要下载的文件' };

  const folder = sanitizeFolder(msg.folder);
  const precheck = msg.precheck !== false;
  return downloadAll(items, folder, precheck);
}

async function downloadAll(items, folder, precheck) {
  job = { ...idleJob(), running: true, total: items.length };
  setBadge(String(items.length));
  keepAlive(true);

  const seen = new Set();
  for (const item of items) {
    if (job.cancelled) break;
    const url = String(item.url);
    if (seen.has(url)) {
      job.done++;
      job.skipped++;
      continue;
    }
    seen.add(url);
    job.current = item.name || url;

    try {
      let probed = null;
      if (precheck) {
        probed = await probe(url);
        if (probed.kind === 'html') {
          job.done++;
          job.skipped++;
          job.log.push({ url, name: item.name, ok: false, reason: '不是文件（返回网页）' });
          broadcast({ type: 'progress', job: snapshot(), item: { url, ok: false, reason: '不是文件（返回网页）' } });
          continue;
        }
      }

      const name = pickName(item, url, probed);
      const path = folder + '/' + name;
      await downloadP(url, path);
      job.ok++;
      job.log.push({ url, name, ok: true });
      broadcast({ type: 'progress', job: snapshot(), item: { url, ok: true, name } });
    } catch (e) {
      job.failed++;
      const reason = String((e && e.message) || e);
      job.log.push({ url, name: item.name, ok: false, reason });
      broadcast({ type: 'progress', job: snapshot(), item: { url, ok: false, reason } });
    } finally {
      job.done++;
      setBadge(job.total - job.done > 0 ? String(job.total - job.done) : '');
    }
    await sleep(180);
  }

  job.running = false;
  setBadge('');
  keepAlive(false);
  broadcast({ type: 'jobDone', job: snapshot() });
  return { ok: true };
}

/* ---------------- 合成 PPTX（交给离屏文档） ---------------- */

let offscreenPending = null;
let deckWaiter = null;

async function ensureOffscreen() {
  try {
    const list = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (list && list.length) return true;
  } catch {
    /* 老版本没有 getContexts */
  }
  if (!offscreenPending) {
    offscreenPending = (async () => {
      try {
        await chrome.offscreen.createDocument({
          url: 'offscreen.html',
          reasons: ['BLOBS'],
          justification: '把录播截图在本地合成 PPTX 再保存',
        });
      } catch (e) {
        const m = String((e && e.message) || e);
        if (!/single offscreen|already/i.test(m)) throw e;
      }
    })().finally(() => {
      offscreenPending = null;
    });
  }
  await offscreenPending;
  return true;
}

function runDeck(msg) {
  const items = (msg.items || []).filter((i) => i && i.url);
  if (!items.length) return Promise.reject(new Error('没有要合成的图片'));

  const prev = job;
  job = {
    ...idleJob(),
    running: true,
    total: items.length,
    phase: 'pptx',
    sessionTotal: prev.sessionTotal || 0,
    sessionDone: prev.sessionDone || 0,
    sessionFail: prev.sessionFail || 0,
  };
  keepAlive(true);
  setBadge('…');

  return ensureOffscreen().then(
    () =>
      new Promise((resolve) => {
        const timer = setTimeout(() => {
          if (deckWaiter) {
            deckWaiter = null;
            finishDeckOuter();
            resolve({ ok: false, error: '合成超时' });
          }
        }, 10 * 60 * 1000);

        deckWaiter = (payload) => {
          clearTimeout(timer);
          deckWaiter = null;
          finishDeckOuter();
          resolve(payload);
        };

        chrome.runtime
          .sendMessage({ type: 'offscreenDeck', items, folder: msg.folder, title: msg.title, dedupe: msg.dedupe !== false })
          .then((r) => {
            if (r && r.ok === false && deckWaiter) {
              const w = deckWaiter;
              deckWaiter = null;
              w({ ok: false, error: r.error || '离屏文档拒绝了任务' });
            }
          })
          .catch((e) => {
            if (deckWaiter) {
              const w = deckWaiter;
              deckWaiter = null;
              w({ ok: false, error: String((e && e.message) || e) });
            }
          });
      })
  );
}

function finishDeckOuter() {
  if (job.running) {
    job.running = false;
    setBadge('');
    keepAlive(false);
  }
}

/* ---------------- 整门课：逐个打开录播页抓截图 ---------------- */

/** MV3 后台闲着 30 秒会被回收，任务期间定时戳一下 API 保命 */
let keepAliveTimer = null;
function keepAlive(on) {
  if (on) {
    if (keepAliveTimer) return;
    keepAliveTimer = setInterval(() => {
      try {
        chrome.runtime.getPlatformInfo(() => void chrome.runtime.lastError);
      } catch {
        /* ignore */
      }
    }, 20000);
  } else if (keepAliveTimer) {
    clearInterval(keepAliveTimer);
    keepAliveTimer = null;
  }
}

function waitTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;
    const onUpd = (id, info) => {
      if (id === tabId && info.status === 'complete') finish();
    };
    const timer = setTimeout(finish, timeoutMs || 35000);
    function finish() {
      if (done) return;
      done = true;
      clearTimeout(timer);
      try {
        chrome.tabs.onUpdated.removeListener(onUpd);
      } catch {
        /* ignore */
      }
      resolve();
    }
    try {
      chrome.tabs.onUpdated.addListener(onUpd);
    } catch {
      finish();
    }
    chrome.tabs
      .get(tabId)
      .then((t) => {
        if (t && t.status === 'complete') finish();
      })
      .catch(finish);
  });
}

/** 让某个 tab 里的 content script 扫一遍，返回它的 scanResult */
function scanInTab(tabId, timeoutMs) {
  const scanId = 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  return new Promise((resolve) => {
    let done = false;
    const timer = setTimeout(() => finish(null), timeoutMs || 45000);
    const onMsg = (msg, sender) => {
      if (!msg || msg.type !== 'scanResult' || msg.scanId !== scanId) return;
      if (sender && sender.tab && sender.tab.id !== tabId) return;
      finish(msg);
    };
    function finish(msg) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      try {
        chrome.runtime.onMessage.removeListener(onMsg);
      } catch {
        /* ignore */
      }
      resolve(msg);
    }
    chrome.runtime.onMessage.addListener(onMsg);
    Promise.resolve(
      chrome.tabs.sendMessage(tabId, {
        type: 'scan',
        scanId,
        opts: { autoScroll: true, probe: false, allowDocs: false },
      })
    ).catch(() => finish(null));
  });
}

async function runCourse(msg) {
  if (job.running) return { ok: false, error: '已有任务在跑' };
  const sessions = Array.isArray(msg.sessions) ? msg.sessions.filter((s) => s && s.url) : [];
  if (!sessions.length) return { ok: false, error: '没有录播地址' };

  const folder = sanitizeFolder(msg.folder);
  job = { ...idleJob(), running: true, total: sessions.length, phase: 'course' };
  job.sessionTotal = sessions.length;
  job.sessionDone = 0;
  job.sessionFail = 0;
  setBadge('…');
  keepAlive(true);

  const collected = [];
  const seenUrls = new Set();

  for (const s of sessions) {
    if (job.cancelled) break;
    const idx = job.sessionDone + 1;
    job.current = `第 ${idx}/${sessions.length} 节：${s.title || s.url}`;
    broadcast({ type: 'courseProgress', job: snapshot(), phase: 'open', index: idx, total: sessions.length, title: s.title || '' });

    let created = null;
    try {
      created = await chrome.tabs.create({ url: s.url, active: false });
      const tabId = created.id;
      await waitTabComplete(tabId);
      // 等截图列表渲染出来，最多试 3 轮
      let res = null;
      for (let attempt = 0; attempt < 3; attempt++) {
        await sleep(1200 + attempt * 1500);
        if (job.cancelled) break;
        const r = await scanInTab(tabId, 45000);
        if (r && Array.isArray(r.items) && r.items.length) {
          res = r;
          break;
        }
      }
      const slides = res ? res.items.filter((i) => i.kind === 'slide') : [];
      if (res && res.error) {
        job.sessionFail++;
        job.log.push({ url: s.url, name: s.title, ok: false, reason: '扫描出错：' + res.error });
      } else if (!slides.length) {
        // 有的节次可能真是传了 pptx 原件，也收下
        const others = res ? res.items.filter((i) => i.kind !== 'slide') : [];
        if (others.length) {
          for (const o of others) {
            if (seenUrls.has(o.url)) continue;
            seenUrls.add(o.url);
            collected.push(o);
          }
        } else {
          job.sessionFail++;
          job.log.push({ url: s.url, name: s.title, ok: false, reason: '没扫到内容' });
        }
      } else {
        const tag = 's' + String(idx).padStart(2, '0') + '_';
        for (const o of slides) {
          if (seenUrls.has(o.url)) continue;
          seenUrls.add(o.url);
          // 加节次前缀：同一门课多节的图排在一起也不打架
          collected.push({ ...o, name: tag + o.name, sessionIdx: idx, sessionTitle: s.title || '' });
        }
        broadcast({ type: 'courseProgress', job: snapshot(), phase: 'ok', index: idx, total: sessions.length, title: s.title || '', count: slides.length });
      }
    } catch (e) {
      job.sessionFail++;
      job.log.push({ url: s.url, name: s.title, ok: false, reason: String((e && e.message) || e) });
    } finally {
      if (created && created.id !== undefined) {
        try {
          await chrome.tabs.remove(created.id);
        } catch {
          /* ignore */
        }
      }
      job.sessionDone++;
      setBadge(String(sessions.length - job.sessionDone));
    }
    await sleep(400);
  }

  if (!collected.length) {
    job.running = false;
    setBadge('');
    keepAlive(false);
    broadcast({ type: 'jobDone', job: snapshot(), error: '一整门课都没扫到截图' });
    return { ok: false, error: '没扫到截图' };
  }

  const slides = collected.filter((i) => i.kind === 'slide');
  if (slides.length && msg.pptx !== false) {
    broadcast({ type: 'courseProgress', job: snapshot(), phase: 'pptx', count: slides.length });

    // 每一节录播单独出一个 PPTX，文件名就用那一节的标题
    const groups = new Map();
    for (const it of slides) {
      const key = it.sessionIdx || 0;
      if (!groups.has(key)) groups.set(key, { title: it.sessionTitle || '', items: [] });
      groups.get(key).items.push(it);
    }

    const fallback = msg.title || folder.split('/').pop() || '课件';
    return (async () => {
      let made = 0;
      let last = null;
      for (const [, g] of groups) {
        const t = (g.title || '').trim() || `${fallback} 第 ${made + 1} 节`;
        const res = await runDeck({ items: g.items, folder, title: t, dedupe: msg.dedupe !== false });
        last = res;
        if (res && res.ok) made++;
        broadcast({
          type: 'pptxDone',
          ok: !!(res && res.ok),
          error: res && res.error,
          filename: res && res.filename,
          pages: res && res.pages,
          bytes: res && res.bytes,
          failed: res && res.failed,
          skipped: res && res.skipped,
          part: `${made}/${groups.size}`,
        });
        await sleep(300);
      }

      if (msg.keepImages) {
        await downloadAll(slides, folder, false);
      }
      job.running = false;
      setBadge('');
      keepAlive(false);
      broadcast({ type: 'jobDone', job: snapshot(), pptx: { ok: made > 0 } });
      return { ok: made > 0, filename: last && last.filename, pages: last && last.pages };
    })();
  }

  broadcast({ type: 'courseProgress', job: snapshot(), phase: 'download', count: collected.length });
  const precheck = false; // 都是图片直链，不用预检
  return downloadAll(collected, folder, precheck);
}

function snapshot() {
  return {
    running: job.running,
    total: job.total,
    done: job.done,
    ok: job.ok,
    skipped: job.skipped,
    failed: job.failed,
    cancelled: job.cancelled,
    current: job.current,
    phase: job.phase || '',
    sessionTotal: job.sessionTotal || 0,
    sessionDone: job.sessionDone || 0,
    sessionFail: job.sessionFail || 0,
    log: job.log.slice(-50),
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return;

  if (msg.type === 'downloadBatch') {
    runBatch(msg).catch((e) => {
      job.running = false;
      setBadge('');
      broadcast({ type: 'jobDone', job: snapshot(), error: String(e) });
    });
    sendResponse({ ok: true, started: true });
    return;
  }

  if (msg.type === 'pptxBlob') {
    // 离屏文档下载失败，后台用同一个 blob 地址再试一次
    chrome.downloads.download(
      { url: msg.url, filename: msg.filename, saveAs: false, conflictAction: 'uniquify' },
      (id) => {
        const err = chrome.runtime.lastError;
        const payload = {
          type: 'pptxDone',
          ok: !err && id !== undefined,
          error: err ? err.message : undefined,
          filename: msg.filename,
          pages: msg.pages,
          bytes: msg.bytes,
          failed: msg.failed,
          skipped: msg.skipped,
          downloadId: id,
        };
        const w = deckWaiter;
        if (w) w(payload);
        broadcast(payload);
      }
    );
    return;
  }

  if (msg.type === 'pptxProgress') {
    if (job.phase === 'pptx') {
      job.done = msg.done || 0;
      job.total = msg.total || job.total;
      job.ok = msg.pages || 0;
    }
    return;
  }

  if (msg.type === 'pptxDone') {
    const w = deckWaiter;
    if (w) w(msg);
    return;
  }

  if (msg.type === 'deckPptx') {
    runDeck(msg)
      .then((res) => {
        broadcast({ type: 'jobDone', job: snapshot(), pptx: res || null });
      })
      .catch((e) => {
        job.running = false;
        setBadge('');
        keepAlive(false);
        broadcast({ type: 'jobDone', job: snapshot(), error: String((e && e.message) || e) });
      });
    sendResponse({ ok: true, started: true });
    return;
  }

  if (msg.type === 'courseScan') {
    runCourse(msg).catch((e) => {
      job.running = false;
      setBadge('');
      broadcast({ type: 'jobDone', job: snapshot(), error: String(e) });
    });
    sendResponse({ ok: true, started: true });
    return;
  }

  if (msg.type === 'getJob') {
    sendResponse({ ok: true, job: snapshot() });
    return;
  }

  if (msg.type === 'cancelJob') {
    job.cancelled = true;
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === 'scanResult') return; // 给 popup 的，不用处理
});

chrome.downloads.onChanged.addListener((delta) => {
  if (delta.state && delta.state.current === 'interrupted') {
    job.log.push({ url: '', name: '', ok: false, reason: '下载中断：' + (delta.error && delta.error.current) });
  }
});
