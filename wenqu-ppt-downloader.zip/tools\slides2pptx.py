#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把问渠学堂录播里的课件截图，按顺序合成一个 PPTX。

用法一（扩展已经下好图片）：
    python slides2pptx.py --dir "D:\\Downloads\\问渠学堂\\水污染控制工程2026-09-14第7-8节"

用法二（手上有一串图片地址）：
    python slides2pptx.py --urls urls.txt --title "水污染控制工程 第7-8节"

urls.txt 每行一条，或者直接粘一段 JSON / HTML 也行（脚本会把里面所有
/ai3/ppt/日期/uuid/文件名.jpg 挑出来）。

输出：<目录名>.pptx，在 --out 指定的位置（默认与目录同级）。
"""

import argparse
import hashlib
import io
import os
import re
import sys
import urllib.request
from collections import defaultdict

SLIDE_RE = re.compile(
    r"https?://[^\s\"'<>()]+?/ai3/ppt/(\d{8})/([0-9a-fA-F-]{8,})/([^\s\"'<>()/]+?\.(?:jpe?g|png))",
    re.I,
)
LOCAL_IMG_RE = re.compile(r"\.(?:jpe?g|png)$", re.I)


def log(*a):
    print(*a, flush=True)


def num_key(name):
    """文件名里的数字（时间戳毫秒），按数值排。"""
    digits = re.sub(r"\D", "", os.path.splitext(name)[0])
    return int(digits) if digits else 0


def pick_urls(text):
    found = SLIDE_RE.findall(text)
    if not found:
        return [], None
    groups = defaultdict(list)
    for date, uuid, fname in found:
        groups[(date.lower(), uuid.lower())].append(fname)
    # 一组里图片最多的，就是这场课的课件
    (date, uuid), names = max(groups.items(), key=lambda kv: len(kv[1]))
    names = sorted(set(names), key=num_key)
    urls = ["https://video.wqxt.cdut.edu.cn/ai3/ppt/{}/{}/{}".format(date, uuid, n) for n in names]
    return urls, "{} {}".format(date, uuid)


def download(urls, out_dir, ua="Mozilla/5.0"):
    os.makedirs(out_dir, exist_ok=True)
    paths = []
    for i, u in enumerate(urls, 1):
        dst = os.path.join(out_dir, "slide_{:04d}.jpg".format(i))
        paths.append(dst)
        if os.path.exists(dst) and os.path.getsize(dst) > 1024:
            log("  [{}/{}] 已有 {}".format(i, len(urls), os.path.basename(dst)))
            continue
        req = urllib.request.Request(u, headers={"User-Agent": ua, "Referer": "https://classroom.wqxt.cdut.edu.cn/"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                data = r.read()
            with open(dst, "wb") as f:
                f.write(data)
            log("  [{}/{}] {} ({} KB)".format(i, len(urls), os.path.basename(dst), len(data) // 1024))
        except Exception as e:
            log("  [{}/{}] 失败 {}: {}".format(i, len(urls), u, e))
            paths.pop()
    return paths


def dedupe(paths):
    """去掉内容完全一样的相邻截图（同一页画面停了几秒会有多张）。"""
    out, prev = [], None
    for p in paths:
        with open(p, "rb") as f:
            h = hashlib.md5(f.read()).hexdigest()
        if h == prev:
            log("  跳重复: {}".format(os.path.basename(p)))
            continue
        prev = h
        out.append(p)
    return out


def build_pptx(paths, out_path, title=None):
    from pptx import Presentation
    from pptx.util import Inches

    prs = Presentation()
    # 16:9
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]

    W, H = prs.slide_width, prs.slide_height
    for p in paths:
        slide = prs.slides.add_slide(blank)
        try:
            from PIL import Image

            with Image.open(p) as im:
                iw, ih = im.size
        except Exception:
            iw, ih = 16, 9
        # 等比铺满（留一点白边也居中）
        scale = min(W / iw, H / ih)
        w, h = int(iw * scale), int(ih * scale)
        slide.shapes.add_picture(p, int((W - w) / 2), int((H - h) / 2), width=w, height=h)

    if title:
        prs.core_properties.title = title
    prs.save(out_path)
    return len(prs.slides._sldIdLst)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", help="已下载图片的目录")
    ap.add_argument("--urls", help="含图片地址的文本/JSON 文件")
    ap.add_argument("--out", help="输出 pptx 路径")
    ap.add_argument("--title", help="标题（写进文件属性）")
    ap.add_argument("--work", default=None, help="临时图片目录")
    ap.add_argument("--keep", action="store_true", help="保留分页截图")
    args = ap.parse_args()

    if args.dir:
        d = os.path.abspath(args.dir)
        paths = [os.path.join(d, f) for f in sorted(os.listdir(d)) if LOCAL_IMG_RE.search(f)]
        if not paths:
            log("目录里没有图片: {}".format(d))
            return 2
        name = args.title or os.path.basename(d.rstrip("\\/"))
        out = args.out or os.path.join(os.path.dirname(d), name + ".pptx")
        log("扫描到 {} 张图".format(len(paths)))
    elif args.urls:
        with io.open(args.urls, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        urls, tag = pick_urls(text)
        if not urls:
            log("文件里没找到 /ai3/ppt/ 图片地址")
            return 2
        name = args.title or tag
        work = args.work or os.path.join(os.getcwd(), "slides_" + (tag or "wqxt").replace(" ", "_"))
        log("找到 {} 张截图（{}）".format(len(urls), tag))
        paths = download(urls, work)
        out = args.out or os.path.join(os.getcwd(), name + ".pptx")
    else:
        ap.error("要么 --dir，要么 --urls")

    paths = dedupe(paths)
    log("去重后 {} 张，开始合成…".format(len(paths)))
    n = build_pptx(paths, out, name)
    log("完成：{}（{} 页）".format(out, n))
    return 0


if __name__ == "__main__":
    sys.exit(main())
